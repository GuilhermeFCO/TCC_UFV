remotes::install_github('rstudio/rmarkdown')
install.packages('knitr')
install.packages('tinytex')
remotes::install_github('rstudio/bookdown')
